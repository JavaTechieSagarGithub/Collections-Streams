package com.defaultmethod;

public class MainApp {
	public static void main(String args[]) {

		MyInterface myimpl = new MyInterfaceImpl();
		myimpl.square(4);

		// default method executed
		myimpl.show();
		myimpl.print();
	}
}
