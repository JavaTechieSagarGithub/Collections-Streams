package com.defaultmethod;

public class MyInterfaceImpl implements MyInterface{
	// implementation of square abstract method 
	
    public void square(int side) { 
    	
        System.out.println("Area of square =  " + side * side); 
        
    } 
}


