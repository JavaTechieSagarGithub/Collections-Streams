package com.defaultmethod;

public interface MyInterface {
	
	    // abstract method 
	    public void square(int side); 
	  
	    // default method 
	    
	    default void show() { 
	    	
	      System.out.println("Default Method Executed"); 
	      
	    }
	    default void print() {
	    	System.out.println("Hi");
	    }
	} 

