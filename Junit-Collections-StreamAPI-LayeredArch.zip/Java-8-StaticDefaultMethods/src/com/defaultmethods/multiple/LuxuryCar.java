package com.defaultmethods.multiple;

public class LuxuryCar  implements Vehicle, FourWheeler {
//Overriding print()
	   public  void print() {
	      Vehicle.super.print();
	   }

}
