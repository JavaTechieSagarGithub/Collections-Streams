package com.defaultmethods.multiple;

public class MainCar {

	public static void main(String[] args) {
		 Vehicle vehicle = new Car();
	      vehicle.print();
	}

}
