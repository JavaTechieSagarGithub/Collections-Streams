package com.staticmethod;

public interface MyInterface {
	
	static void sayHello() { 
        System.out.println("Hello, New Static Method"); 
    } 
	// other method signatures
}
