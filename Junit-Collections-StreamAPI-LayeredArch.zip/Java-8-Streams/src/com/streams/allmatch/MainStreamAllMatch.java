package com.streams.allmatch;

import java.util.List;
import java.util.function.Predicate;

public class MainStreamAllMatch {

	public static void main(String[] args) {
		Predicate<Student> predi1= student -> student.name.startsWith("S");
	      Predicate<Student> predi2 = student-> student.age == 28;// && student.name.startsWith("Z");       
	      List<Student> list = Student.getStudents();

	      /* allMatch() method checks whether any Stream element matches
	       * the specified predicate
	       */
	      boolean isStartingWithS = list.stream().allMatch(predi1);
	      System.out.println("All match - Student name starts with S " + isStartingWithS);
	      boolean isAgeBelow28 = list.stream().allMatch(predi2);
	      System.out.println("All Match Student age == 28 " + isAgeBelow28);
	}

}
