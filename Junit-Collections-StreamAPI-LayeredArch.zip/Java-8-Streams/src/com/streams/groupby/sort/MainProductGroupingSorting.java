package com.streams.groupby.sort;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MainProductGroupingSorting {

	public static void main(String[] args) {
		
		List<Product> products = new ArrayList<Product>();
		products.add(new Product("Refrigerator", 10, 25631.25f));
		products.add(new Product("Woven", 20, 26354.25f));
		products.add(new Product("Washing Machine", 10, 29356.75f));
		products.add(new Product("Refrigerator", 10, 18369.25f));
		products.add(new Product("Refrigerator", 20, 15326.25f));
		products.add(new Product("Woven", 10, 18693.25f));
		products.add(new Product("Refrigerator", 10, 17589.95f));
		products.add(new Product("Woven", 20, 14539.75f));
		products.add(new Product("Washing Machine", 10, 29356.75f));
		products.add(new Product("Washing Machine", 10, 29356.75f));
		
		Map<String, Long> counting1 = products.stream()
				.collect(Collectors.groupingBy(Product::getName, Collectors.counting()));

		System.out.println(counting1);

		Map<String, Integer> sum1 = products.stream()
				.collect(Collectors.groupingBy(Product::getName, Collectors.summingInt(Product::getQty)));

		System.out.println(sum1);

		Map<String, Long> counting2 = products.stream()
				.collect(Collectors.groupingBy(Product::getName, Collectors.counting()));

		System.out.println("Grouping products - counting\t" + counting2);

		Map<String, Integer> sum2 = products.stream()
				.collect(Collectors.groupingBy(Product::getName, Collectors.summingInt(Product::getQty)));

		System.out.println("Group by products - summing Quantity\t" + sum2);

	}

}
