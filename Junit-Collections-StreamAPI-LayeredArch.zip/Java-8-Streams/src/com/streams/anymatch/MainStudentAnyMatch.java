package com.streams.anymatch;

import java.util.List;
import java.util.function.Predicate;

public class MainStudentAnyMatch {

	public static void main(String[] args) {
		  // to find the names starting with S
	      Predicate<Student> predi1= student -> student.name.startsWith("S");
	      
	      Predicate<Student> predi2 = student-> student.age < 28 && student.name.startsWith("Z");       
	      List<Student> list = Student.getStudents();

	      /* anyMatch() method checks whether any Stream element matches
	       * the specified predicate
	       */
	      boolean isStartingWithS = list.stream().anyMatch(predi1);
	      System.out.println("Any match - Student name starts with S " + isStartingWithS);
	      
	      boolean isAgeBelow28 = list.stream().anyMatch(predi2);
	      System.out.println("Any Match Student age < 28 " + isAgeBelow28);
	   }

}
