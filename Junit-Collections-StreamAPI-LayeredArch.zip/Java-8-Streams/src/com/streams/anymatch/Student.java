package com.streams.anymatch;
import java.util.List;
import java.util.ArrayList;
class Student{
   int id;
   int age; 
   String name; 
   Student(int id, int age, String name){ 
      this.id = id;  
      this.age = age; 
      this.name = name; 
   } 
   public int getid() { 
      return id; 
   } 
   public int getage() { 
      return age; 
   }
   public String getname() { 
      return name; 
   } 
   
   public static List<Student> getStudents(){        
	   
       List<Student> list = new ArrayList<>();        
       list.add(new Student(11, 28, "Lucy"));        
       list.add(new Student(28, 27, "Kiku"));        
       list.add(new Student(32, 30, "Dani"));        
       list.add(new Student(49, 27, "Steve"));       
       return list;    
       
   }
}