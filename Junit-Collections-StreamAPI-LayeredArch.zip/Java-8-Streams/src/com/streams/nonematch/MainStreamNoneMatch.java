package com.streams.nonematch;

import java.util.List;
import java.util.function.Predicate;

public class MainStreamNoneMatch {

	public static void main(String[] args) {
		Predicate<Student> predi1= student -> student.name.startsWith("S");
		
	      Predicate<Student> predi2 = student-> student.age == 28;// && student.name.startsWith("Z");       
	      List<Student> list = Student.getStudents();

	      /* noneMatch() method checks whether any Stream element matches
	       * the specified predicate
	       */
	      boolean isStartingWithS = list.stream().noneMatch(predi1);
	      System.out.println("None match - Student name starts with S " + isStartingWithS);
	      boolean isAgeBelow28 = list.stream().noneMatch(predi2);
	      System.out.println("None Match Student age ==28 " + isAgeBelow28);
	}

}
