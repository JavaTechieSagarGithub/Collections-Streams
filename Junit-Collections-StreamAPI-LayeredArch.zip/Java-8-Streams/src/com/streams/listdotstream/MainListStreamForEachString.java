package com.streams.listdotstream;

import java.util.Arrays;
import java.util.List;

public class MainListStreamForEachString {
	public MainListStreamForEachString() {
		 // Creating a list of Strings 
        List<String> list = Arrays.asList("Java", "Python", "Spring"); 
  
        // Using forEach(Consumer action) to 
        // print the elements of stream 
        list.stream().forEach(System.out::println); 
	}
}
