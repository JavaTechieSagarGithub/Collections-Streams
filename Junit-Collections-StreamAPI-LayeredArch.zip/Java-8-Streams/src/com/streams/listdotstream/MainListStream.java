package com.streams.listdotstream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class MainListStream {
	public static void main(String[] args) {
        List<Integer> list = new ArrayList<Integer>();

        for(int index = 1; index< 10; index++){
            list.add(index);
        }

        Stream<Integer> stream = list.stream();
        stream.forEach(value -> System.out.println(value));
        
        // String.join()
        
        String[] names = {"Bill", "Bob", "Steve" };
        String fullString = String.join(" ", names);
        System.out.print(fullString + " ");
        
        
    }
}


