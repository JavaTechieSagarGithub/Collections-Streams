package com.streams.listdotstream.withwithoutstreams;

import java.util.ArrayList;
import java.util.List;

public class MainStringListWithStreams {

	public static void main(String[] args) {
		List<String> technologies = new ArrayList<String>();
		technologies.add("Java");
		technologies.add("Python");
		technologies.add("MySQL");
		technologies.add("Spring Framework");
			
		//Using Stream and Lambda expression
		long count = technologies.stream().filter(str->str.length()<6).count();
		System.out.println("There are "+count+" strings with length less than 6");	}

}
