package com.streams.listdotstream.withwithoutstreams;

import java.util.ArrayList;
import java.util.List;

public class MainStringListWithoutStreams {

	public static void main(String[] args) {
		List<String> technologies = new ArrayList<String>();
		technologies.add("Java");
		technologies.add("Python");
		technologies.add("MySQL");
		technologies.add("Spring Framework");
		// boilerplate code
		int count = 0;
		for (String str : technologies) {
		   if (str.length() < 6) 
			count++; 
		}
	        System.out.println("There are "+count+" strings with length less than 6");

	}

}
