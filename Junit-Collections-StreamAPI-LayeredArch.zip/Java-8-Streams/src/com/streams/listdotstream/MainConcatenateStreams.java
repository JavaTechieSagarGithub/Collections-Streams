package com.streams.listdotstream;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
public class MainConcatenateStreams {
   public static void main(String[] args) {
	//list 1
	List<String> databases = Arrays.asList("MySQL","SQL * Plus","Mongo DB");
	//list 2
	List<String> technologies = Arrays.asList("\nJava","Python","Dot Net");
		
	//creating two streams from the two lists and concatenating them into one
	Stream<String> opstream = Stream.concat(databases.stream(), technologies.stream());
		
	//displaying the elements of the concatenated stream
	opstream.forEach(str->System.out.print(str+" "));
   }
}