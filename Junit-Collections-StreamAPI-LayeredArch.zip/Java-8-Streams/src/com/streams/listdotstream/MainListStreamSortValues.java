package com.streams.listdotstream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MainListStreamSortValues {

	public static void main(String[] args) {
		// Creating a list of Integers 
        List<Integer> list = Arrays.asList(2, 6, 8, 4, 10); 
  
        // Using forEach(Consumer action) to 
        // print the elements of stream in sorted order
         System.out.println("Sorted Order");
        list.stream().sorted().forEach(System.out::println); 
        
     // print the elements of stream in sorted order
        System.out.println("Reverse Sorted Order");
        list.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);// Method reference 

        
	}

}
