package com.streams.filter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainCollectionFilterBefore {

	public static void main(String[] args) {
		List<String> technologies = Arrays.asList("Spring", "Java", "Python");
		
        List<String> result = getFilterOutput(technologies, "Java");
        
        for (String temp : result) {
            System.out.println(temp);    
        } 
	}	
		private static List<String> getFilterOutput(List<String> technologies, String filter) {
		        List<String> result = new ArrayList<>();
		        
		        
		        for (String technology : technologies) {
		            if (  !"Java".equals(technology)  ) { 
		                result.add(technology);
		            }
		        }
		        return result;//"Spring" and "Python"
		    }
		 	 
	}


