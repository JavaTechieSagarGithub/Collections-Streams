package com.streams.filter;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class MainCollectionFilterAfter {

	public static void main(String[] args) {

		List<String> technologies = Arrays.asList("Spring", "Java", "Python");
		System.out.println("Using List\n------------");
		
		List<String> result = technologies
				.stream()
				.filter(java -> !"Java".equals(java) ).collect(Collectors.toList() ); // filtered collection is converted into List object

		result.forEach(System.out::println); // Method reference
		
		System.out.println("\nUsing Set\n------------");
		
		Set<String> technologiesSet = (Set<String>) technologies
				.stream().filter(java -> !"Java".equals(java))
				.collect( Collectors.toSet() ); // filtered collection is converted into Set object

		technologiesSet.forEach(System.out::println); // Method reference
	}

}
