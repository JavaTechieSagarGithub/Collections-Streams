package com.streams.streamdotof;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MainValuesStream {

	public static void main(String[] args) {
		
		Stream<Integer> stream = Stream.of(1,2,3,4,5,6,7,8,9);
		Stream<String> stream2 = Stream.of("HYD","PUNE","BENGALURU");
		// iterates with single forEach() method no classic for loop
		
        stream.forEach(value -> System.out.println(value) );
        stream2.forEach(value-> System.out.println(value) );
        // converting Streams into Collections
        List<Integer> streamToList = Stream.of(1,2,3,4,5,6,7,8,9)
        							    .collect( Collectors.toCollection(ArrayList :: new));
        streamToList.forEach(System.out::println);
	}

}


