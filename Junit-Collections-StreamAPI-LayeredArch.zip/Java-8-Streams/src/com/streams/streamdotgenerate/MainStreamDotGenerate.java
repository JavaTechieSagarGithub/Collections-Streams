package com.streams.streamdotgenerate;

import java.util.Random;
import java.util.stream.Stream;

public class MainStreamDotGenerate {

	public static void main(String[] args) {
		
		System.out.println("Random numbers");
		Stream.generate(Math :: random)
	      .limit(5)
	      .forEach(System.out :: println);
		
		System.out.println("Random Integers");
		Stream.generate(new Random()::nextInt) 
	    .limit(5).forEach(System.out :: println);  
	    } 
	}





	