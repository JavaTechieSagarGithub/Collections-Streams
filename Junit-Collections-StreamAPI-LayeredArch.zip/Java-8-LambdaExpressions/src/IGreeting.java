@FunctionalInterface
public interface IGreeting {

	public void sayHello(String name);
	
}
