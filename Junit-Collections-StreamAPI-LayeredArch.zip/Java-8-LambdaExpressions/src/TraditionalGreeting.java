
public class TraditionalGreeting  implements IGreeting{

	@Override
	public void sayHello(String name) {
		
		System.out.println("Hello "  + name);
		
	}

	

	

}


