package com.lambda.arithmetic;

public interface MathOperator {
	
	int operation(int a, int b);
}
