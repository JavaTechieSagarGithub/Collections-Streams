package com.lambda.arithmetic;
public class LambdaMathOpertator {

	public static void main(String[] args) {
		//Creation of object, overriding method	
		
		MathOperator sum = (int num1, int num2) -> num1 + num2;// expression - not a method in a class 
		
		//invoke method
		System.out.println("Sum = " +sum.operation(12, 23) );// no overriding operation method
	
		// with out type declaration
		MathOperator difference = (int num1, int num2) -> num1-num2;
		
		System.out.println("Difference= " + difference.operation(23, 12) );
		// with return statement along with curly braces

		
		MathOperator product = (int num1,  int num2) -> { return num1 * num2; };
		System.out.println("Product = " + product.operation(23, 25) );
		
		MathOperator quotient = (int num1, int num2) -> (num1 / num2);
		System.out.println("Quotient  = " + quotient.operation(20, 5) );
		
		MathOperator remainder = (int num1, int num2)->(num1 % num2);
		System.out.println("Remainder = " + remainder.operation(21,2) );
	}
}
