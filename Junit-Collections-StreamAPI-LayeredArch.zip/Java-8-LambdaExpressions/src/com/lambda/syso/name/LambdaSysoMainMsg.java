package com.lambda.syso.name;

public class LambdaSysoMainMsg {
	
	public static void main(String[] args) {
		
		// without parenthesis - creating objects No implements keyword
		GreetingService greetService1 = message -> System.out.println("Hello " + message);
		
		// with parenthesis - creating objects
		GreetingService greetService2 = (message) -> System.out.println("Hi " + message);
		
		greetService1.sayGreeting("Sagar");
		greetService2.sayGreeting("Nesha");
	}
}
