package com.lambda.syso.name;

public interface GreetingService {
	
	 void sayGreeting(String message);
	 
}
