
public class TraditionalMainApp {

	public static void main(String[] args) {
		TraditionalGreeting tg = new TraditionalGreeting();
		tg.sayHello("Kumar");

	}

}
