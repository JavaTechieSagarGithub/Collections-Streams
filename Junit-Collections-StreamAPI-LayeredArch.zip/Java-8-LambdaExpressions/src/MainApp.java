
public class MainApp {

	public static void main(String[] args) {
		TraditionalGreeting tg = new TraditionalGreeting();
		tg.sayHello("Kumar");
		tg.sayHello("Prasad");

	}

}
