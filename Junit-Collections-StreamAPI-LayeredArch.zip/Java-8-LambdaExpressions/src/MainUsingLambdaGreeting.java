
public class MainUsingLambdaGreeting {

	public static void main(String[] args) {
		
		// with arguments - implementing the interface method
		IGreeting greetingsInstance = (name) -> System.out.println("Hello World " + name);

		// (name) -> System.out.println("Hello World " + name); is replacement of
		/*
		 * public class TraditionalGreeting implements IGreeting{
		 * 
		 * @Override
		 * 
		 *  public void sayHello(String name) {
		 * 
		 * 		System.out.println("Hello " + name);
		 *  }
		 */

		greetingsInstance.sayHello("Kumar");
	}

}
