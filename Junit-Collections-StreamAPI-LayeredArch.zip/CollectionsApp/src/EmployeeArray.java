import java.util.Arrays;
import java.util.Scanner;
public class EmployeeArray {

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
		Employee[] employees = new Employee[4];// creates array of references but not objects
		
		// create objects and store in array
		for( int index=0; index < employees.length ; index++ ) {
			System.out.println("Enter Employee " + (index+1) + " Details");
			int id,age;
			String name;
			System.out.println("Enter Employee Id ");
			id = scnr.nextInt();
			System.out.println("Enter Name ");
			name = scnr.next();
			System.out.println("Enter Age ");
			age = scnr.nextInt();
			
			employees[ index ] = new Employee( id, name, age );
		}
		
			
		for( Employee employee : employees ) {
			//System.out.println( employee.getId() + "    " +  employee.getName() + "\n" );
			System.out.println( employee );
		}
	}

}

