package com.mycom.collections.map;

import java.util.HashMap;
import java.util.Map;

public class MapHttpError {
	public static void main(String[] args) {

		Map<Integer, String> mapHttpErrors = new HashMap<Integer,String>();
		 
		mapHttpErrors.put(200, "OK");
		mapHttpErrors.put(303, "See Other");
		mapHttpErrors.put(404, "Not Found");
		mapHttpErrors.put(500, "Internal Server Error");
		System.out.println( mapHttpErrors);
	}
	 
}
