package com.mycom.collections.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class MapEmployeeObjectWithId {

	public static void main(String[] args) {
		/* This is how to declare HashMap */
		HashMap<Integer, Employee> empMap = new HashMap<Integer, Employee>();
		Scanner scnr = new Scanner(System.in);
		// Read employee data
		for (int empId = 1001; empId <= 1005; empId++) {

			System.out.println("Enter employee name, job and salary of id  " + empId);
			Employee emp = new Employee(scnr.nextLine(), scnr.nextLine(), scnr.nextFloat());
			scnr.nextLine();
			/* Adding elements to HashMap */
			empMap.put(empId, emp);
			emp = null;

		}
		/* Display content using Iterator */

		Set set = empMap.entrySet(); // key and values are returned by entrySet()

		Iterator iterator = set.iterator();

		while (iterator.hasNext()) {

			Map.Entry empEntry = (Map.Entry) iterator.next();
			System.out.print("Key is: " + empEntry.getKey());
			Employee emp = (Employee) empEntry.getValue(); // retrieves Employee object
			System.out.println("Employee details of id " + empEntry.getKey() + "are " + emp.getName() + "\t\t"
					+ emp.getJob() + "\t\t" + emp.getSalary());
		}

		/* Get values based on key */
		Employee emp = empMap.get(1002); // Retrieves Employee name whose id is 1002
		System.out.println("Employee details of id 1002 are : " + emp.getName() + "\t\t" + emp.getJob() + "\t\t"
				+ emp.getSalary());

	}

}
