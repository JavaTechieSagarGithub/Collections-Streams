package com.mycom.collections.map;

import java.util.LinkedHashMap;
import java.util.Set;

public class CountryCapitalNavigationMap {

	public static void main(String[] args) {
		
		LinkedHashMap<String, String> capitalCities = new LinkedHashMap<String, String>();
		
		capitalCities.put("England", "London");
		capitalCities.put("Germany", "Berlin");
		capitalCities.put("Norway", "Oslo");
		capitalCities.put("USA", "Washington DC");
						
		System.out.println(  capitalCities.get("England"));
		System.out.println(  capitalCities.get("Norway"));
		capitalCities.put("India", "New Delhi");
		// keySet() - returns all keys as Set object
		Set<String> keys = capitalCities.keySet();

		System.out.println("The Values using get(key) method are : ");
		// Set keys = capitalCities.keySet()
		for (String key : capitalCities.keySet()) {
			System.out.println( "Key : " +  key + " Value  :  " + capitalCities.get( key ) );
		}
	}

}

