package com.mycom.collections.map;

import java.util.HashMap;

public class EvenOddMap {
	public static void main(String[] args) {
        // Creating HashMap of even numbers
        HashMap<String, Integer> evenNumbers = new HashMap<>();

        // Using put()
        evenNumbers.put("Two", 2);
        evenNumbers.put("Four", 4);

        // Using putIfAbsent()
        evenNumbers.putIfAbsent("Six", 6);
        System.out.println("HashMap of even numbers: " + evenNumbers);
        evenNumbers.put("Four",8);
        
        

        //Creating HashMap of numbers
        HashMap<String, Integer> numbers = new HashMap<>();
        numbers.put("One", 1);

        // Using putAll()
        numbers.putAll(evenNumbers);
        System.out.println("HashMap of numbers: " + numbers);
        //Removing One object
        numbers.remove("One");
        System.out.println("HashMap of numbers: " + numbers);
        
        //Removing object using both key and value with remove() mehod.
        numbers.remove("Three",3);
        
        System.out.println("HashMap of numbers after removing Three, 3 : " + numbers);
        
        
    }
}
