package com.mycom.collections.map;

import java.util.HashMap;

public class PeopleNameAgeMap {
	public static void main(String[] args) {

	    // Create a HashMap object called people
	    HashMap<String, Integer> people = new HashMap<String, Integer>();


	    // Add keys and values (Name, Age)
	    people.put("John", new Integer(32));
	    people.put("Steve", 30);// primitive 30 is auto converted into  Integer object - Auto boxing
	    people.put("Angie", 33);

	    for (String key : people.keySet()) {
	      System.out.println("key: " + key + "\tvalue: " + people.get(key) );
	    }
	  }
}
