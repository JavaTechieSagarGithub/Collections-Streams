package com.mycom.collections.map;

import java.util.HashMap;

import java.util.Scanner;
public class EmployeeObjectsMap {

	public static void main(String[] args) {
		Integer id; // key
		
		String name, job;
		float salary;
		Scanner scnr = new Scanner(System.in);
		
		HashMap<Integer,Employee> empMap = new HashMap<Integer,Employee>();
		
		for(int count = 1; count<=2; count++) {
			
			System.out.println("Enter Employee Id (Key) ");
			id = scnr.nextInt();
			scnr.nextLine();
			
			System.out.println("Enter Employee details - name, job, salary");
			name = scnr.nextLine();
			job = scnr.nextLine();
			salary = scnr.nextFloat();
			scnr.nextLine();
			Employee emp = new Employee(name,job,salary);
			
			empMap.put(id, emp);//key which is Interger object , emp is value of Employee class object
			id = null;// Garbage collected automatically
			emp = null; // Garbage collected automatically
		}
				
		// Iteration on keys
		for(Integer key : empMap.keySet() ) {
	     		Employee emp = empMap.get(key);// retrieves employee object
			    System.out.println("Emp Id: " + key + " Name : " + emp.getName() + "\t" +  " Job :  " +emp.getJob() + "\t" +  " Salary :  " +emp.getSalary() );
			    emp=null;
		}
	}

}
