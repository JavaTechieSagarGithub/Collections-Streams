package com.mycom.collections.map;

import java.util.HashMap;

public class CountryCapitalMap {

	public static void main(String[] args) {
		// Create a HashMap object called capitalCitiesMap
	    
		HashMap<String, String> capitalCitiesMap = new HashMap<String, String>();

	    // Add keys and values (Country, City)
	    capitalCitiesMap.put("England", "London");
	    capitalCitiesMap.put("Germany", "Berlin");
	    capitalCitiesMap.put("Norway", "Oslo");
	    capitalCitiesMap.put("USA", "Washington DC");
	    
	    System.out.println(capitalCitiesMap);
	    
	    // to get value by inputting key
	    System.out.println("Capital of England is : ");
	    
	    System.out.println(capitalCitiesMap.get("England")); // returns London
	    
	    capitalCitiesMap.remove("Germany");
	    
	    System.out.println(capitalCitiesMap);
	}

}
