package com.mycom.collections.map;

import java.util.HashMap;

public class NumbersEntrySetMap {
	public static void main(String[] args) {

		HashMap<String, Integer> numbers = new HashMap<>();

		numbers.put("One", 1);
		numbers.put("Two", 2);
		numbers.put("Three", 3);
		System.out.println("HashMap: " + numbers);

		// Using entrySet()
		System.out.println("Key/Value mappings: " + numbers.entrySet() );
	}
}
