package com.mycom.collections.map;

import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;

public class MapEmployeeIdNameMapEntry {

	public static void main(String args[]) {

		/* This is how to declare HashMap */
		HashMap<Integer, String> empMap = new HashMap<Integer, String>();

		/* Adding elements to HashMap */
		empMap.put(1001, "Chaitanya");
		empMap.put(1002, "Rahul");
		empMap.put(1003, "Singh");
		empMap.put(1004, "Ajeet");
		empMap.put(1005, "Anuj");
		/* Display content using Iterator */
		Set set = empMap.entrySet(); // key and values are returned by entrySet()
		Iterator iterator = set.iterator();
		while (iterator.hasNext()) {
			Map.Entry empEntry = (Map.Entry) iterator.next();
			System.out.print("key is: " + empEntry.getKey() + " & Value is: " + empEntry.getValue() );
		}
		/* Get values based on key */
		String empName = empMap.get(1002); // Retrieves Employee name whose id is 1002
		System.out.println("Value at index 1002 is: " + empName);

		/* Remove values based on key */
		empMap.remove(1002);
		
		
		System.out.println("Map key and values after removal:");
		Set set2 = empMap.entrySet();
		Iterator iterator2 = set2.iterator();
		while (iterator2.hasNext()) {
			Map.Entry mentry2 = (Map.Entry) iterator2.next();
			System.out.print("Key is: " + mentry2.getKey() + " & Value is: ");
			System.out.println(mentry2.getValue());
		}

	}
}