package com.mycom.collections.map;

import java.util.Iterator;
import java.util.TreeMap;

public class NumberMapIterator {
	
	public static void main(String[] args) {
		
		TreeMap<Integer, String> numberMap = new TreeMap<>();

		numberMap.put(21, "Twenty One");
		numberMap.put(31, "Thirty One");
		
		Iterator<Integer> keySetIterator = numberMap.keySet().iterator();
		
		while ( keySetIterator.hasNext() ) {
			Integer key = keySetIterator.next();
			System.out.println("key: " + key + " value: " + numberMap.get(key ));
		}

		TreeMap<String, Integer> numberMap2 = new TreeMap<>();

		numberMap2.put("Twenty One", 21);
		numberMap2.put("Thirty One", 31);
		
		Iterator<String> keySetIterator2 = numberMap2.keySet().iterator();
		
		while ( keySetIterator2.hasNext() ) {
			String key = keySetIterator2.next();
			System.out.println("key: " + key + " value:  " + numberMap2.get(key));
		}

	}
}
