package com.mycom.collections.sortnreverse.list;

import java.io.*;
import java.util.*;

public class MainUser {
	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);

		ArrayList<User> userList = new ArrayList<User>();
		try {
			System.out.println("Enter the number of users:");
			int num = sc.nextInt();
			sc.nextLine();
			for (int i = 0; i < num; i++) {
				System.out.println("Enter the details of User - name,mobile number,city  ... " + (i + 1));
				String userInfo = sc.nextLine();
				String user[] = userInfo.split(",");
				userList.add(new User(user[0], user[1], user[2]));

			}
			Collections.sort(userList);
			System.out.println("The user details in sorted order:\n");
			System.out.println("Name           Mobile number   		City");

			for (User user : userList) {
				System.out.println(user.toString());
			}

			Collections.reverse(userList);
		} catch (Exception e) {

		} finally {
			System.out.println("The user details in reverse sorted order:\n");
			System.out.println("Name           Mobile number   		City");
			for (User user : userList) {
				System.out.println(user.toString());
			}
		}
	}
}