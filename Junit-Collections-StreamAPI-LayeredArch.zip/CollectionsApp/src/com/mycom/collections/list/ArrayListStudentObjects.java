package com.mycom.collections.list;

import java.util.ArrayList;

public class ArrayListStudentObjects {
	public static void main(String[] args) {
		
		ArrayList<Student> studentList = new ArrayList<Student>();
		
		
		Student studentObj = new Student();
		studentObj.setId(1002);
		studentObj.setName("Kumar");
		studentObj.setMarks(96.25f);
		
		studentList.add (studentObj );
		
		studentObj = null;
		
		studentObj = new Student();
		
		studentObj.setId( 1001 );
		studentObj.setName("Satish");
		studentObj.setMarks(98.35f);
		studentList.add(studentObj);
		
		
		for(Student student :  studentList ) {
			
			System.out.println( student.getId()  + "\t\t"  + student.getName() + "\t\t" + student.getMarks() ) ;
			
		}
	}

}
