package com.mycom.collections.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayToArrayListCustomObjects {
	public static void main(String[] args) {
	  Student students[] = new Student[2	];
	  
	  students[0]= new Student();
	  students[1]= new Student();
	  
	  
	  students[0].setId(1001);
	  students[0].setName("Kumar");
	  students[1].setId(1002);
	  students[1].setName("Ram");
	  // converting an array of object into arraylist
	  List<Student> studentList = Arrays.asList(students);
	  for(Student student : studentList) {
		  System.out.println( student.getId() + "   " + student.getName() );
	  }
	}
}
