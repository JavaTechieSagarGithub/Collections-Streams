package com.mycom.collections.list;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListLanguages {
	public static void main(String[] args){

	    // create ArrayList
	    ArrayList<String> langList = new ArrayList<String>();// Generics

	    // Add elements to ArrayList
	    langList.add("C"); 
	    langList.add("Java");
	    langList.add("Python");
	    langList.add("Java Script");
	    
	    System.out.println("Before language list sorting");
		for (String lang : langList) {
			System.out.println(lang);
		}
		
		Collections.sort(langList);
		
		System.out.println("After  language list sorting");
		for (String lang : langList) {
			System.out.println(lang);
		}
	    

	  }
}
