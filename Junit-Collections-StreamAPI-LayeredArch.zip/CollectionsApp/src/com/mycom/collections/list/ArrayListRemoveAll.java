package com.mycom.collections.list;
import java.util.ArrayList;
import java.util.List;
public class ArrayListRemoveAll {
	public static void main(String[] args) {
		// create an ArrayList
		List<String> languages1 = new ArrayList<String>();// like super class reference and sub class object

		// insert element at the end of arraylist
		languages1.add("Java");
		languages1.add("English");
		languages1.add("C");
		languages1.add("Spanish");
		System.out.println("Languages1: " + languages1);
		// create another arraylist
		ArrayList<String> languages2 = new ArrayList<>();

		// add elements to the arraylist
		languages2.add("English");
		languages2.add("Spanish");
		languages2.add("French");
		System.out.println("Languages2: " + languages2);

		// remove all elements of ArrayList2 from ArrayList1 - objects that are common
		// objects that are available in langauages2 which are common in languages1 will be removed.
		languages1.removeAll(languages2);
		
		System.out.println("Languages1 after removeAll(): " + languages1);
		System.out.println("Languages2 after removeAll(): " + languages2);
		
		System.out.println("Are objects available in languages1?  :  " + languages1.isEmpty() );
		
		
		
		
		
		
		
		
/*		ArrayList<String> languages3 = new ArrayList<>();

		// insert element at the end of arraylist
		languages3.add("Java");
		languages3.add("English");
		languages3.add("C");
		languages3.add("Spanish");
		System.out.println("Languages1: " + languages3);
		languages3.clear();
		System.out.println("Languages3: " + languages3.isEmpty());
*/
	}
}