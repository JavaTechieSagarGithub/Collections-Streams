package com.mycom.collections.list;

import java.util.ArrayList;

public class ArrayListAddAll {

	public static void main(String[] args) {
		ArrayList<String> cityList = new ArrayList<>();    //list 1
        
        cityList.add("Bengaluru");
        cityList.add("Hyderabad");
         
        ArrayList<String> cityList2 = new ArrayList<>();    //list 2
         
        cityList2.add("Erode");
        cityList2.add("Pune");
        
        cityList.addAll(cityList2);
         
        System.out.println(cityList);      //combined list
	}

}
