package com.mycom.collections.list;

import java.util.ArrayList;
import java.util.Collections;

public class EmployeeListSorter {

	public static void main(String[] args) {
		ArrayList<Employee> empList = new ArrayList<Employee>();

	// Employee emp = new Employee(111, "Krishna", 24) ;
		// empList.add(emp);
		empList.add(new Employee(209, "Ajeet", 32) );
		empList.add(new Employee(223, "Chaitanya", 26) );
		empList.add(new Employee(245, "Rahul", 24) );
		empList.add(new Employee(111, "Krishna", 24) );
		
		System.out.println("Employee objects before sorting..!");
		System.out.println(empList);

		Collections.sort(empList);//compareTo will be called for every 2 objects in the collection
		
		System.out.println("Employee objects after sorting..!");
		for (Employee emp : empList) {
			System.out.println(emp);
		}
	}

}
