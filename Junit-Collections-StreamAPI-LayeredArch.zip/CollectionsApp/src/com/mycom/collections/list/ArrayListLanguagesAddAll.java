package com.mycom.collections.list;

import java.util.List;
import java.util.ArrayList;

public class ArrayListLanguagesAddAll {
 public static void main(String[] args) {
	

	// create ArrayList
    List<String> langList = new ArrayList<String>();

    // add() method without the index parameter
    langList.add("Java");
    langList.add("C");
    langList.add("Python");
    System.out.println("ArrayList: " + langList);
     
    List<String> langList2 = new ArrayList<String>();
    
    langList2.add("Node JS");
    langList2.add("Angular JS");
    
    System.out.println("Array List 2 "  +langList2 );
    System.out.println("Adding langList2 to langList ...");
    
    langList.addAll( langList2 );
    
    langList.add(  langList2.get(1)  ) ;
    System.out.println("Language List after updation" + langList );
    System.out.println("Language List2 : " + langList2 );
    langList.remove(0);
    System.out.println("ArrayList after deleting first object : " + langList);
    
    langList.remove("Angular JS");
    System.out.println("ArrayList after deleting 'Angular JS' object : " + langList);
    langList.add(2, "MySQL");
    System.out.println("ArrayList after adding 'MySQL' object : " + langList);
 }
}
