package com.mycom.collections.list;
import java.util.ArrayList;
public class ArrayListRemove {
	public static void main(String[] args) {
		ArrayList<String> langList = new ArrayList<String>();

	    // add elements in the array list
	    langList.add("Java");
	    langList.add("Python");
	    langList.add("C++");
	    System.out.println("ArrayList: " + langList);

	    System.out.println(" Deleting Python");
	    String str = langList.remove(1);// using index
	    System.out.println("Removed string object from collection is --- "  + str);
	    System.out.println("ArrayList: " + langList);
	    
	    boolean hasRemoved = langList.remove("Java"); // using object
	    if( hasRemoved  ) {
	    	System.out.println(" The object Java has been removed");
	    } else {
	    	System.out.println(" The object Java has not found");
	    }
	    System.out.println(langList);
	    langList.add("Python");
	    boolean hasRemoved2 = langList.remove("Java");
	    
	    if( hasRemoved2  ) {
	    	System.out.println(" The object Java has been removed");
	    } else {
	    	System.out.println(" The object Java has not found");
	    }
	    
	}
}
