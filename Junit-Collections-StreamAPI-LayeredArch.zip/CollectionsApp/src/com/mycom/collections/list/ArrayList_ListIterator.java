package com.mycom.collections.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.ListIterator;

public class ArrayList_ListIterator {

	public static void main(String[] args) {
		// adding string objects array to the constructor of ArrayList
		  ArrayList<String> cityList = new ArrayList<>(    Arrays.asList("Ahmedabad", "Bengaluru", "Indore", "Pune")    );// asList() converts an array into ArrayList
	         
	        ListIterator<String> listItr = cityList.listIterator();
	         
	        System.out.println("===========Forward=========");
	         
	        while(listItr.hasNext()) {
	            System.out.println(listItr.next());
	        }
	         
	        System.out.println("===========Backward=========");
	         
	        while(listItr.hasPrevious()) {
	            System.out.println(listItr.previous());
	        }
	        Collections.sort(cityList);
	        
	        System.out.println("City List after sorting...!");
	        
	        for(String city : cityList) {
	        	System.out.println(city);
	        }

	}

}
