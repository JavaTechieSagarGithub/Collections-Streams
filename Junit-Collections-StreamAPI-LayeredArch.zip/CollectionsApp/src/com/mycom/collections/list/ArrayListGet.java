package com.mycom.collections.list;

import java.util.ArrayList;
public class ArrayListGet {
	public static void main(String[] args) {
		 ArrayList<String> langList = new ArrayList<String>();//<String> generic collections

		    // add() method without the index parameter
		    langList.add("Java");// index 0
		    langList.add("C");//index 1
		    langList.add("Python");// index 2
		    langList.add("C#");// index 3
		    //size()- returns the no of objects in the list
		    
		    System.out.println("Size of list   : "  + langList.size())  ; 
		    
		    for( int index=0; index < langList.size()  ;  index++ ) {
		    	// get() retuns the object at the given index of the list
		    	System.out.println( langList.get( index ) );
		    }
		    // for each / iterator version of for loop
		    System.out.println("Retrieving Objects from array list using for each loop!");
		    for(  String lang :  langList  ) {
		    	System.out.println( lang );
		    }
		    langList.add("SQL");
		    
		    for(  String lang :  langList  ) {
		    	System.out.println( lang );
		    }
	}
}
