package com.mycom.collections.list;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentListHandler {
	public static void main(String[] args) {
		Student student = new Student();
		// To add student pojos to arraylist
		
		ArrayList<Student> studentList = new ArrayList<Student>();
		Scanner scnr = new Scanner(System.in);
		int choice;
				
		while (true) {
			System.out.println("1. Add students 2. Read students 3.Exit");
			choice = scnr.nextInt();
			switch (choice) {
				case 1:
					System.out.println("Enter student id, name, marks");
					// dont use variables to input the values and send to setters
					student.setId( scnr.nextInt() );
					scnr.nextLine();
					student.setName( scnr.nextLine() );
					student.setMarks( scnr.nextFloat() );
					scnr.nextLine();
					// add the student object to studentList
					studentList.add( student );
					student=null;
					student = new Student();
				    break;
				case 2:
					System.out.println("Student Details!");
					
			        //Collections.sort( (List<Student>) studentList);
					for( Student studentobj: studentList ) {
						System.out.println("Student Id: " + studentobj.getId() + "\tStudent Name  " + studentobj.getName() + "\t Student marks " + studentobj.getMarks() ); 
						
					}
				   break;
				case 3:
					System.out.println("Thank you for using the app!");
					scnr.close();
					System.exit(0);// terminates the application
					break;
				}
				
		}

	}

}
