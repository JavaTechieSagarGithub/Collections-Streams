package com.mycom.collections.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsMaxMethod {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>(); 
		  
        
        list.add(-1); 
        list.add(4); 
        list.add(-5); 
        list.add(1); 
        Collections.sort(list);
        System.out.println("Sorted List : "  + list);
        
        Collections.reverse(list);
        System.out.println("Reversed Sorted List : "  + list);
        // prining the max value 
        // using max() method 
        System.out.println("Max val: " + Collections.max(list) );
        
	}

}
