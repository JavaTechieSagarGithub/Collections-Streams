package com.mycom.collections.list;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListApp {

	public static void main(String[] args) {

		LinkedList<String> list = new LinkedList<String>();

		// Adding elements to the Linked list
		list.add("Steve");
		list.add("Carl");
		list.add("Raj");

		// Adding an element to the first position
		list.addFirst("Negan");

		// Adding an element to the last position
		list.addLast("Rick");
		System.out.println("Linked list after adding first and last elements  : " + list);
		// Adding an element to the 3rd position
		list.add(2, "Glenn");

		// Iterating LinkedList
		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		// change RIck to Fedrick - set(5,"Fedrick")
		list.set(5, "Fedrick");
		iterator = list.iterator();
		System.out.println( "List after modifying Rick ");
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		

	}

}
