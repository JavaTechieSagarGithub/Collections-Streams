package com.mycom.collections.list;

public class Employee implements Comparable {
	private int empid;
	private String empname;
	private int empage;
// Alt+Shift+S+R - setters and getters
	//Alt+Shift+S+O - constructor
	
	public Employee(int empid, String empname, int empage) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empage = empage;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public int getEmpage() {
		return empage;
	}

	public void setEmpage(int empage) {
		this.empage = empage;
	}

	
	// compareTo to perform sorting
		public int compareTo(Object emp2) {
			
			int compareid = ((Employee) emp2).getEmpid();// reference casting

			return this.empid - compareid;
		
		}

		@Override
		public String toString() {
			return "Employee -- empid=" + empid + ", empname=" + empname + ", empage=" + empage;
		}
}







//String empname = ((Employee) emp2 ).getEmpname();
// current employee object id - 2nd employee object id, 3rd employee object
// id.....nth employee obj id

// return this.empname.compareTo(empname);