package com.mycom.collections.list;

import java.util.ArrayList;

public class ArrayListLanguagesAddAtIndex {
	 public static void main(String[] args){
		    // create ArrayList
		    ArrayList<String> langList = new ArrayList<String>();

		    // add() method without the index parameter
		    langList.add("Java");
		    langList.add("C");
		    langList.add("Python");
		    System.out.println("ArrayList: " + langList);
		    langList.add("C++");
		    
		    
		    // add() method with the index parameter
		    langList.add(1, "JavaScript");
		    System.out.println("Updated ArrayList: " + langList);
		  }
}
