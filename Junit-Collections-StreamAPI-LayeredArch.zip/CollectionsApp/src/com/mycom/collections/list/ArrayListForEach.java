package com.mycom.collections.list;

import java.util.ArrayList;

public class ArrayListForEach {
	public static void main(String[] args) {
		ArrayList<String> langList = new ArrayList<String>();

	    // add() method without the index parameter
	 
		langList.add("Java");
	    langList.add("C");
	    langList.add("Python");
	    
	    Object[] langs = langList.toArray();
	    System.out.println("Lang Array :");
	    
	    System.out.println(langs[0] + "      "    +  langs[1] ) ;
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    	    
	   /* System.out.println("Lang Array :");
	    System.out.println(langs[0] + "      "    +  langs[1] ) ;
	    
	    for( String lang : langList ) {
	    	System.out.println( lang );
	    }
	    
	    langList.remove("JavaAdv");// clears the collection
	    langList.add(1,"Spring");
	    System.out.println("Size after deletion / clear - "  +langList.size() );
	    
	    langList.add("Angular");
	    
	    for( String lang : langList ) {
	    	System.out.println( lang );
	    }
	    System.out.println("Size  " + langList.size() ); 
	    langList.add("");
	    langList.add("");
	    langList.add("");
	    System.out.println("Size  " + langList.size() ); 
	
	     
	    
	    */
	}
}
