package com.mycom.collections.list;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArraysAsList {

	
	public static void main(String[] args) {
		List<String> names = Arrays.asList("Alex", "Charles", "Brian", "David"); // names.add("Alex"); names.add("Charles")
	
		for(String name  :  names) {
			System.out.println(name);
		}
		 System.out.println("List after sorting collection");
		//Natural order
		
		 Collections.sort(names);    //[Alex, Brian, Charles, David]
		for(String name  :  names) {
			System.out.println(name);
		}
		
		//Reverse order
		Collections.sort (names, Collections.reverseOrder() );
		
		System.out.println("List after sorting collection in reverse order");
		for(String name  :  names) {
			System.out.println(name);
		}

	}

}
