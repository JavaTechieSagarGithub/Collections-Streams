package com.mycom.collections.set;

import java.util.HashSet;

public class HashSetRemoveAll {    public static void main(String[] args) {
    // create an HashSet
    HashSet<String> languages1 = new HashSet<>();

    // insert element at the end of arraylist
    languages1.add("Java");
    languages1.add("English");
    languages1.add("C");
    languages1.add("Spanish");
    System.out.println("Languages1: " + languages1);
    // create another arraylist
    HashSet<String> languages2 = new HashSet<>();
    // add elements to the arraylist
    languages2.add("English");
    languages2.add("Spanish");
    System.out.println("Languages2: " + languages2);
    // remove all elements of HashSet2 from HashSet1  - objects that are common in both lists will be removed
    languages1.removeAll(languages2);
    System.out.println("Languages1 after removeAll(): " + languages1);
    System.out.println("Languages2 after removeAll(): " + languages2);
    languages2.clear();
    System.out.println("Languages3: " + languages2.isEmpty());
    
}
}