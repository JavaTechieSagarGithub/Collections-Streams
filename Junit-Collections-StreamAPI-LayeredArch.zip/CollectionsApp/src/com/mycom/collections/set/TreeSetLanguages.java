package com.mycom.collections.set;

import java.util.TreeSet;

public class TreeSetLanguages {

	public static void main(String[] args) {
		TreeSet<String> langSet = new TreeSet<String>();

	    // Add elements to TreeSet
	    langSet.add("Java");
	    langSet.add("Python");
	    langSet.add("C++");
	    langSet.add("Java");
	    langSet.add("C");
	    langSet.add("Fortran");
	    for( String lang : langSet) {
	    	System.out.println( lang );
	    }

	}

}
