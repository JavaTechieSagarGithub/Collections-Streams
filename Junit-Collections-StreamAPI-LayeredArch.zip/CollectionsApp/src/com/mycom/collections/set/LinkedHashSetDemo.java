package com.mycom.collections.set;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {
	public static void main(String[] args) {
		
	
	// LinkedHashSet of String Type
    LinkedHashSet<String> linkedCityset = new LinkedHashSet<String>();

    // Adding elements to the LinkedHashSet
    linkedCityset.add("Pune");
    linkedCityset.add("Ahmedabad");
    linkedCityset.add("Nagpur");
    linkedCityset.add("Hyderabad");
    linkedCityset.add("Bengaluru");
    System.out.println(linkedCityset);
    
    
/*
    // LinkedHashSet of Integer Type
    LinkedHashSet<Integer> lhset2 = new LinkedHashSet<Integer>();

    // Adding elements
    lhset2.add(99);
    lhset2.add(7);
    lhset2.add(0);
    lhset2.add(67);
    lhset2.add(89);
    lhset2.add(66);
    System.out.println(lhset2);*/
	}
}
