package com.mycom.collections.set;

import java.util.HashSet;

public class HashSetForEach {
	public static void main(String[] args) {
		HashSet<String> langSet= new HashSet<String>(); // unordered collection

	    // add() method without the index parameter
	    langSet.add("Java");
	    langSet.add("C");
	    langSet.add("Python");// 
	    langSet.add("Java Script");
	    langSet.add("Python");// duplicate object
	    
	    //repeting the same set of objects 
	    
	    
	    langSet.add("java");// adds "java"
	    langSet.add("C");// willl not add
	    langSet.add("Python");// will not add
	    langSet.add("Java Script");// will not add
	    langSet.add("Python");//will not add
	    
	    
	    for( String lang : langSet ) {
	    	System.out.println( lang );
	    }
	    
	    
	    HashSet<Integer> intSet = new HashSet<Integer>();
	    intSet.add(100);
	    intSet.add(200);
	    
	    System.out.println(intSet);
	    
	    intSet.remove(200);
	    
	    System.out.println(intSet);
	}
}
