package com.mycom.collections.set;

public class HashCodeFinder {

	public static void main(String[] args) {
		
		String str1 = "Hello";
		String str2 = "Hello";
		
		String str3 = new String("Hello");
		
		System.out.println("Hash code of str1 - "  + str1.hashCode());
		System.out.println("Hash code of str2 - "  + str2.hashCode());
		System.out.println("Hash code of str3 - "  + str3.hashCode());
		
		Student student1 = new Student(1001,"Kumar");
		Student student2 = new Student(1001,"Kumar");		
		
		System.out.println("Hash code of student1 - " + student1.hashCode());
		System.out.println("Hash code of student2 - " + student2.hashCode());
	}

}
