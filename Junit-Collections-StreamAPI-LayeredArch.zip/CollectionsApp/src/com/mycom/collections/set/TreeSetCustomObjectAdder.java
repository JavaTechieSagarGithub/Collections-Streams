package com.mycom.collections.set;

import java.util.TreeSet;

public class TreeSetCustomObjectAdder {
	TreeSet<Student> studentSet = new TreeSet<>();
	
	Student rk = new Student(67890, "Sagar");
	Student vs = new Student(12345,"Ronak");
	
	public void addStudents() {
		studentSet.add(rk);
		studentSet.add(vs);
	}
	
	public void showStudentDetails() {
		for(Student student : studentSet) {
			System.out.println(student.getId() + "\t\t\t"  + student.getName());
		}
	}
 }
