package com.mycom.collections.set;

import java.util.TreeSet;

public class TreeSetStudentObjects {

	public static void main(String[] args) {
		
		TreeSet<Student> idComp = new TreeSet<Student>(new StudentIdComparator( ) );
		idComp.add( new Student(1002, "Ram") );
		idComp.add( new Student(1001, "John") );
		idComp.add( new Student(1004, "Crish") );
		idComp.add( new Student(1003, "Tom") );
		System.out.println( "Student details sorted on Id : \n");
		
		for (Student student : idComp) {
			System.out.println( student.getId() + "\t" + student.getName() );
		}	
				
		// By using name comparator (String comparison)
		TreeSet<Student> nameComp = new TreeSet<Student>( new StudentNameComparator() );
		nameComp.add( new Student(1002, "Ram") );
		nameComp.add( new Student(1001, "John") );
		nameComp.add( new Student(1004, "Crish") );
		nameComp.add( new Student(1003, "Tom") );

		System.out.println( "Student details sorted on Name : \n");
		for (Student student : nameComp) {
			System.out.println(student.getId() + "\t" + student.getName());
		}

		
	}
}