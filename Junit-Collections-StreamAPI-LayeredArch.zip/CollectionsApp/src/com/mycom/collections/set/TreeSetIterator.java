package com.mycom.collections.set;

import java.util.TreeSet;
import java.util.Iterator;

public class TreeSetIterator {

	public static void main(String[] args) {
		TreeSet<String> langSet = new TreeSet<String>();

		// add() method without the index parameter
		langSet.add("Java");
	
		langSet.add("Python");
		langSet.add("C");
		Iterator itr = langSet.iterator();
		
		while( itr.hasNext() ) { // is next object available? true / false
			System.out.println(  itr.next() ); // if object available in the iterator - get it
		}

	}

}
