package com.mycom.collections.set;

import java.util.TreeSet;

public class HashSetLanguages {
	public static void main(String[] args){

	    // create TreeSet
	    TreeSet<String> langSet = new TreeSet<String>();

	    // Add elements to HashSet
	    langSet.add("java");
	    langSet.add("Python");
	    langSet.add("C++");
	    langSet.add("Java");
	    langSet.add("C++");

	    for( String lang : langSet) {
	    	System.out.println( lang );
	    }
	 
	  }
}
