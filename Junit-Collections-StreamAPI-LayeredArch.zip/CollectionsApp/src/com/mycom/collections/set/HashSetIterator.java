package com.mycom.collections.set;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetIterator {
	public static void main(String[] args) {
		HashSet<String> langSet = new HashSet<String>();

		// add() method without the index parameter
		langSet.add("Java");
	
		langSet.add("Python");
		langSet.add("C");
		
        Iterator<String> itr = langSet.iterator();
//		@SuppressWarnings("rawtypes")
//		Iterator  itr = langSet.iterator();	
		while( itr.hasNext() ) { // is next object available? true / false
			System.out.println(  itr.next() ); // if object available in the iterator - get it
		}
	}
}
