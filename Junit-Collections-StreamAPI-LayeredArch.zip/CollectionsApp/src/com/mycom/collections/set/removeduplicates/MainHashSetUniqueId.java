package com.mycom.collections.set.removeduplicates;

import java.util.HashSet;
import java.util.Set;

public class MainHashSetUniqueId {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Employee> employeeSet = new HashSet<Employee>();

		employeeSet.add(new Employee(1001, "Nesha"));
		employeeSet.add(new Employee(1002, "Abhivira"));

		// add duplicate object with same id
		employeeSet.add(new Employee(1001, "Kumar"));
		employeeSet.add(new Employee(1002, "Prasad"));
		employeeSet.add(new Employee(1001, "Kumar"));
		employeeSet.add(new Employee(1002, "Prasad"));
		employeeSet.add(new Employee(1003, "Kumar"));
		employeeSet.add(new Employee(1004, "Prasad"));
		for (Employee emp : employeeSet) {
			System.out.println("Employee Id: " + emp.getId());
			System.out.println("Employee Name: " + emp.getName());
			System.out.println("Hash code : " + emp.hashCode());
		}
	}

}
