package com.mycom.collections.set;

import java.util.TreeSet;

public class TreeSetForEach {
	public static void main(String[] args) {
		TreeSet<String> langSet= new TreeSet<String>();

	    // add() method without the index parameter
	    langSet.add("Java");
	    langSet.add("C");// C Java
	    langSet.add("java Script");//C Java java Script
	    langSet.add("Python");//C Java Python java Script
	    langSet.add("C++");//C C++ Java Python java Script
	    langSet.add("java Script");//C C++ Java Python java Script
	    
	    for( String lang : langSet ) {
	    	System.out.println( lang );
	    }
	}
}
