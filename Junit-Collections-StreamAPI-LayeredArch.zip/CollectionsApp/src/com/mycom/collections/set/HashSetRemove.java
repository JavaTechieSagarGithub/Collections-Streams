package com.mycom.collections.set;

import java.util.HashSet;

public class HashSetRemove {
	public static void main(String[] args) {
		HashSet<String> langSet = new HashSet<>();

	    // add elements in the array list
	    langSet.add("Java");
	    langSet.add("Python");
	    langSet.add("C++");
	    System.out.println("HashSet: " + langSet);

	    System.out.println(" Deleting Java");
	    @SuppressWarnings("unlikely-arg-type")
		boolean isRemoved= langSet.remove(0); 
	    System.out.println( "Is langSet(0) removed..?  " + isRemoved );
	    
	    langSet.remove("C++");
	    
	    System.out.println("Language set after deleting C++");
	    
	    System.out.println("HashSet: " + langSet);
	    
	    
	}
}
