package com.mycom.collections.set;

public class MainAppStudentTreeSet {

	public static void main(String[] args) {
		
		TreeSetCustomObjectAdder tscoa = new TreeSetCustomObjectAdder();
		tscoa.addStudents();
		tscoa.showStudentDetails();

	}

}
