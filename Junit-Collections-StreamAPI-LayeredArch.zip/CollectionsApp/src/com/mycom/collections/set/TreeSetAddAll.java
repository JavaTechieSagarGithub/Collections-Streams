package com.mycom.collections.set;

import java.util.TreeSet;

public class TreeSetAddAll {
	public static void main(String[] args) {
		
	
	// create ArrayList
    TreeSet<String> langSet = new TreeSet<String>();

    // add() method without the index parameter
    langSet.add("Java");
    langSet.add("C"); 
    langSet.add("Python");
    System.out.println("TreeSet: " + langSet);
     
    TreeSet<String> langSet2 = new TreeSet<String>();
    langSet2.add("Node JS");
    langSet2.add("Angular JS");
    langSet2.add("node JS");
    System.out.println("Array List 2 "  +langSet2 );
    System.out.println("Adding langSet2 to langSet ...");
    langSet.addAll(langSet2);
    System.out.println("Language List after updation" + langSet );

	}
}
