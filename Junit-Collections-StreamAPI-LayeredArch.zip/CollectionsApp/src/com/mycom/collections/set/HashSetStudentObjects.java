package com.mycom.collections.set;

import java.util.HashSet;

public class HashSetStudentObjects {
	
	public static void main(String[] args) {
		
		HashSet<Student> studentSet = new HashSet<Student>();
		
		Student studentObj1 = new Student(1001,"Kumar");
		Student studentObj2 = new Student(1002,"Krishna");
		Student studentObj3 = new Student(1003,"Prerana");
		Student studentObj4 = new Student(1003,"Prerana");
		//studentObj.setId(1001);
		//studentObj.setName("Kumar");
		
		studentSet.add(studentObj1);
		studentSet.add(studentObj2);
		studentSet.add(studentObj3);
		studentSet.add(studentObj4);
		
		
		for(Student student :  studentSet ) {
			System.out.println( student.getId()  + "\t\t"  + student.getName()  );
		}
		// Hash code - unique address location for each object in heap memory
		System.out.println(studentObj1.hashCode());
		System.out.println(studentObj2.hashCode());
		System.out.println(studentObj3.hashCode());
		System.out.println(studentObj4.hashCode());
		System.out.println(studentSet.hashCode());
	}

}
