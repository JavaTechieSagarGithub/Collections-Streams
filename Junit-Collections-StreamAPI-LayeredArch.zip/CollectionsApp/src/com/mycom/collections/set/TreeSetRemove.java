package com.mycom.collections.set;

import java.util.TreeSet;

public class TreeSetRemove {
	public static void main(String[] args) {
		TreeSet<String> langSet = new TreeSet<>();

		// add elements in the array list
		langSet.add("Java");
		langSet.add("Python");
		langSet.add("C++");
		langSet.add("C") ;
		langSet.add("Angular") ;
		langSet.add("React") ;
		langSet.add("Node") ;
		
		System.out.println("TreeSet: " + langSet);

		System.out.println(" Deleting Java");
	//	boolean str = langSet.remove(0);
		//System.out.println(str);
		langSet.remove("C++");
		System.out.println("TreeSet: " + langSet);
	}
}
