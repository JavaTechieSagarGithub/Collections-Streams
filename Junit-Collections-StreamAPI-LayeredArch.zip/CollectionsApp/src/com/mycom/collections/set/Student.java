package com.mycom.collections.set;

public class Student {
	int id;
	String name;
	
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	/*@Override
	public int compareTo(Object obj) {
	//	 int nxtid=( (Student) obj).getId();// reference casting
		 return this.getName().compareTo( ((Student) obj).getName() );	  
	}*/
}
