package com.mycom.empcomparator;
import java.util.Comparator;

public class IdComparator implements Comparator{
   
    public int compare(Object emp1, Object emp2){
   
        /*
         * parameter are of type Object, so we have to downcast it
         * to Employee objects
         */
       
        int emp1Id = ((Employee)emp1).getId();        
        int emp2Id = ((Employee)emp2).getId();
       
        if(emp1Id > emp2Id)
            return 1;
        else if(emp1Id < emp2Id)
            return -1;
        else
            return 0;    
    }
   
}
 