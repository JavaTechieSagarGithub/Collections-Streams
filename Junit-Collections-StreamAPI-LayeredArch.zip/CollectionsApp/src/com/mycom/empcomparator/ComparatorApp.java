package com.mycom.empcomparator;

import java.util.Arrays;
public class ComparatorApp{

	    public static void main(String args[]){
	       
	        //Employee array which will hold employees
	        Employee employee[] = new Employee[2];
	       
	        //set different attributes of the individual employee.
	        employee[0] = new Employee(40,"Joe");
	               
	        employee[1] = new Employee(20,"Mark");
	       
	        System.out.println("Order of employee before sorting is");
	        //print array as is.
	        for(int i=0; i < employee.length; i++){
	            System.out.println( "Employee " + (i+1) + " name :: " + employee[i].getName() + ", Id :: " + employee[i].getId());
	        }
	       
	        //Sorting array on the basis of employee age by passing AgeComparator
	        Arrays.sort(employee, new IdComparator());
	        System.out.println("\n\nOrder of employee after sorting by employee age is");
	       
	        for(int i=0; i < employee.length; i++){
	            System.out.println( "Employee " + (i+1) + " name :: " + employee[i].getName() + ", Age :: " + employee[i].getId());
	        }
	       
	        //Sorting array on the basis of employee Name by passing NameComparator
	        Arrays.sort(employee, new NameComparator());
	       
	        System.out.println("\n\nOrder of employee after sorting by employee name is");    
	        for(int i=0; i < employee.length; i++){
	            System.out.println( "Employee " + (i+1) + " name :: " + employee[i].getName() + ", Age :: " + employee[i].getId());
	        }
	   
	    }
	 
	}

