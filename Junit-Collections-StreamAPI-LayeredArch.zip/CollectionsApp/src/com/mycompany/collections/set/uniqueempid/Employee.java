package com.mycompany.collections.set.uniqueempid;

public class Employee {

	private int id;
	private String name;

	Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public final void setId(int id) {
		this.id = id;
	}

	public final int getId() {
		return this.id;
	}

	public final void setName(final String name) {
		this.name = name;
	}

	public final String getName() {
		return this.name;
	}
}












//public int hashCode() {
//
//		int hash = id;
//
//		return hash;
//	}
//
//	public boolean equals(Object obj) {
//
//		Employee employee = (Employee) obj; // reference casting
//		if (employee.getId() == this.id) {
//			return true;
//		} else
//			return false;
//	}


