package com.mycompany.collections.set.uniqueempid;

import java.util.HashSet;
import java.util.Set;

public class MainHashSetUniqueId {

	public static void main(final String[] args) {
		// TODO Auto-generated method stub
		 Set<Employee> employeeSet = new HashSet<Employee>();
		
		 employeeSet.add(new Employee(1, "Nesha"));
		 employeeSet.add(new Employee(2, "Abhivira"));
		 
		
		 employeeSet.add(new Employee(1,"Nesha"));
		 
	
	     for(Employee emp : employeeSet) {
	    	 System.out.println("Employee Id: " + emp.getId() );
			 System.out.println("Employee Name: " + emp.getName() );}

	     }

}
