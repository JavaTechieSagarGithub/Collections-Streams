@FunctionalInterface 
interface MyInterface{  
    void display();  
}  