package com.methodref.staticmethod.two;

public class MethodReferenceThread {
	public static void threadStatus(){  
        System.out.println("Thread is running...");  
    }  
    public static void main(String[] args) {  
        Thread t2=new Thread(MethodReferenceThread :: threadStatus);  
        t2.start();       
    }  
}
