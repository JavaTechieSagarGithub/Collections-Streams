package com.methodref.staticmethod.two;

public interface Sayable {
	void say();  
}
