package com.methodref.staticmethod.one;

import java.util.Arrays;
import java.util.List;


public class MethodReferenceStaticMethod {

	public static void main(String[] args) {
		List<String> langList = Arrays.asList("Java", "Python", "MySQL", "Angular");


		// lambda expression
		System.out.println("Using lamba expressions");
		langList.forEach(str -> SimplePrinter.print(str));

		// method reference
		System.out.println("Using method references");
		langList.forEach(SimplePrinter :: print);
	}
}
