package com.methodref.staticmethod.one;

public class SimplePrinter {
	
	public static void print(String str) {
		
		System.out.println(str);
		
	}
	
}