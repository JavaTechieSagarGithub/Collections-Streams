package com.methodref.constructor;

public interface Messageable {
	
	 Message getMessage(String msg);  
}
