package com.methodref.predef.bifunction.three;

import java.util.function.BiFunction;

public class MethodRefPredefBiFunction {


		public static void main(String[] args) {  
			
			BiFunction<Integer, Integer, Integer> adder = Arithmetic :: add;  
			int result = adder.apply(10, 20);  // apply is a method in BiFunction
			System.out.println("Sum = " + result);  
			}  

	}


