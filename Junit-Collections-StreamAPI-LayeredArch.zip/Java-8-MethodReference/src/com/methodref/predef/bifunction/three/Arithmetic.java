package com.methodref.predef.bifunction.three;

public class Arithmetic {
	public static int add(int num1, int num2) {
		return num1 + num2;
	}
}
