package com.methodref.predef.bifunction.override.four;

public class Arithmetic {
// Over loading methods
	public static int add(int num1, int num2) {
		return num1 + num2;
	}

	public static float add(int num1, float num2) {
		return num1 + num2;
	}

	public static float add(float num1, float num2) {
		return num1 + num2;
	}
}
