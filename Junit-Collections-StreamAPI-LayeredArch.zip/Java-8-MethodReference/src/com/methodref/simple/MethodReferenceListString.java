package com.methodref.simple;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class MethodReferenceListString {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("node", "java", "python", "ruby");
		
		
		// Using lamba expressions
		System.out.println("Using lamba expressions");
		
		List<String> listLambda = Arrays.asList("node", "java", "python", "ruby");
		listLambda.forEach(str -> System.out.println(str)); // lambda

		// Using method references
		System.out.println("Using method references");
		
		List<String> listMethodRef = Arrays.asList("node", "java", "python", "ruby");
		listMethodRef.forEach(System.out::println);

		// With method reference,  better readability is gained

	}
}