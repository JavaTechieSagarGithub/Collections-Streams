package com.methodref.simple;

import java.util.ArrayList;

public class MethodReferenceForEach {

	public static void main(String[] args) {
		
		 ArrayList<String> names = new ArrayList<String>();
			
	      names.add("Mahesh");
	      names.add("Suresh");
	      names.add("Ramesh");
	      names.add("Naresh");
	      names.add("Kalpesh");
			
	      names.forEach(System.out::println);// System.out.println(names[0],....names[1]...
	      
	      /* for(String name : names){
	       * 	System.out.println(name);
	       * }
	       */

	}

}
