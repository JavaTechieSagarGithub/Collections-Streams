import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestHelloWorld {

	@Test
	void test() {
		System.out.println("First Test");
	}

}
