package com.mycom.bankbalance;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import junit.framework.TestCase;

public class TestBankAccount extends TestCase{
	BankAccount acc;

    @BeforeEach                       // This will run **before** EACH @Test
    public void setUptestDepositUpdatesBalance(){
        acc = new BankAccount(100);  
    } 
    @AfterEach                        // This Will run **after** EACH @Test
    public void tearDown(){
     acc = null;
    }
    @Test
    public void testDeposit(){
       // no need to instantiate a new BankAccount(), @Before does it for us
    	acc = new BankAccount(100);  
    	acc.deposit(100);
        assertEquals(acc.getBalance(),200); 
    }
    @Test
    public void testWithdrawUpdatesBalance(){    
    	acc = new BankAccount(100);  
    	acc.withdraw(40);
        assertEquals(acc.getBalance(),60); // pass
    }
    @Test
    public void testWithdrawAppliesPenaltyWhenOverdrawn(){
    	acc = new BankAccount(100);  
        acc.withdraw(120);
        assertEquals(acc.getBalance(),-20);
    }
}
