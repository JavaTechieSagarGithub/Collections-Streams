package com.mycom.junit.allassertions;

public class FibonacciCalculator {

}
