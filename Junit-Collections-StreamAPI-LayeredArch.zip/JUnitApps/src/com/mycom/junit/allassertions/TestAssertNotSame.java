package com.mycom.junit.allassertions;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TestAssertNotSame {
	@Test
	public void test1() {
		String str1 = "Apple";
		String str2 = "Apple";
		Assertions.assertSame(str1, str2);
	}

	// public static void assertNotSame(Object expected, Object actual, String
	// message)
	@Test
	public void test2() {

		String str1 = new String("Apple");
		String str2 = new String("Apple");
		Assertions.assertNotSame(str1, str2, "str1 and str2 refer to same object");
	}

	// public static void assertNotSame(Object expected, Object actual, Supplier
	// messageSupplier)
	@Test
	public void test3() {
		String str1 = new String("Apple");
		String str2 = str1;
		Assertions.assertNotSame(str1, str2, "str1 and str2 refer to same object");
	}
}
