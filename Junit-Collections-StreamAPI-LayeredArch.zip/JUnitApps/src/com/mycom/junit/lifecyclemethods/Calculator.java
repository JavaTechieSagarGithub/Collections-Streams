package com.mycom.junit.lifecyclemethods;

public class Calculator {
	public static int add(int num1, int num2) {
		return num1 + num2;
	}
}		
