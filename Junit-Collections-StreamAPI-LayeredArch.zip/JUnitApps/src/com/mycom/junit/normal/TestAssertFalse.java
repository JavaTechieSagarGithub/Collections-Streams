package com.mycom.junit.normal;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestAssertFalse {
	
	 public static boolean isEvenNumber(int number){
         
	        boolean result = false;
	        if(number%2 == 0){
	            result = true;
	        }
	        return result;
	    }
	     
	    @Test
	    public void evenNumberTest(){

	        assertTrue(  isEvenNumber( 4 ) );
	    }
}
