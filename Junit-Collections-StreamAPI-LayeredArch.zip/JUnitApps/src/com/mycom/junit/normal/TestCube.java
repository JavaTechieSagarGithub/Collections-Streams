package com.mycom.junit.normal;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.junit.Test;

public class TestCube {
	@Test  
	    public void testCube(){  
		
	       // System.out.println("test case cube");  
		    Scanner scnr = new Scanner(System.in);
		    System.out.println("Enter test data...");
		    int num = scnr.nextInt();
	        assertEquals( 19683, Cube.findCube( num ) ); 
	        // 27 is expected result, Cube.findCube() is test case  / test condition
	        assertEquals( -8, Cube.findCube( -2 ) );
	        assertEquals( 0, Cube.findCube( 0 ) );
	        
	    }  

}
