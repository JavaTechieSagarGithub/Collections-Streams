package com.mycom.junit.normal;

public class MainMaxElementFinder {

	public static void main(String[] args) {
		
		MaxElementFinder mef = new MaxElementFinder();
		int marks[] = {96,3,6,47,59,86 };
		int max = mef.findMax( marks );
		System.out.println("Maximum mark is : "  + max);
		
	}

}
