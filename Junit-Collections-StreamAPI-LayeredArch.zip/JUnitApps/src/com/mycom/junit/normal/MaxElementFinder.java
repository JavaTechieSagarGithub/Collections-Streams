package com.mycom.junit.normal;

public class MaxElementFinder {

	public int findMax(int arr[]) {

		//int max = 0;
		int max = Integer.MIN_VALUE;
		
		for( int num : arr) {
			if( num>max ) {
				max = num;
			}
		}

		return max;
	}
}
