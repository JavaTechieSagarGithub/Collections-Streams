package com.mycom.junit.normal;

import static org.junit.Assert.fail;

import org.junit.jupiter.api.Test;

public class TestFail {
	@Test
	public void incompleteTest() {
	    fail("Not yet implemented");
	}
}
