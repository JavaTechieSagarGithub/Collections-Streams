package com.mycom.junit.normal;

import junit.framework.*;

public class TestCaseDemo extends TestCase {
	
	protected int num1, num2;
	protected void setUp() {
		num1 = 10;
		num2 = 20;
	}
	public void testAdd() {
		int sum = num1 + num2;
		assertTrue( sum == 30);
	}
	protected void tearDown() {
		num1=num2=0;
	}
	
	
}
