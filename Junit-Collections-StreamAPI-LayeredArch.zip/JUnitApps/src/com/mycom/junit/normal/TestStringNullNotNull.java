package com.mycom.junit.normal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.junit.Test;

public class TestStringNullNotNull {
	@Test
	public void setUp() {
		String str1 = null;
		String str2 = "hello";              
		String str3 = new String( "hello" );

		// Success.
		assertNull(str1);// test case passes

		
		assertNotNull(str2);// test case fails, if null, test case passes if not null
		
		assertNotSame(str2, str3);
		assertNotSame(str1,str2);
		assertEquals(str3,str2);// contents are compared
	}

}
