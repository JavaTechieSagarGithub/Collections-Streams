package com.mycom.junit.normal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestAdminStringReader {
	@Test
	public void testSetup() {
		

		AdminStringReader adminStrReader = new AdminStringReader();
		
		String str = adminStrReader.readString();
		
		//assertEquals("admin" , str );
		assertTrue( str.equalsIgnoreCase("admin") );
	
		
	}

}
