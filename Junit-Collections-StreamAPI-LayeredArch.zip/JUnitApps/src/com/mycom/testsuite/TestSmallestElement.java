package com.mycom.testsuite;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestSmallestElement {  

	@Test
	public void testFindSmallest() {
		assertTrue ( 3 < 6 );
	}
	
}
