import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestFirstJUnitDemo {
	//@Test specify the following method is an unit to be tested
	@Test
	void test() {
		System.out.println("First Test");
	}

}
