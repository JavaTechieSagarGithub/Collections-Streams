package com.functionclass;

import java.util.function.Function;

public class FunctionApply {

    public static void main(String[] args) {

        Function<String, Integer> func = str ->  + str.length();

        int apply = func.apply("Vidya Sagar");   // returns 5 - no of characters

        System.out.println("No of characters : " + apply);

    }

}