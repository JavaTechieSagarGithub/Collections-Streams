package com.functionalinterface;

@FunctionalInterface
public interface Square {
	int calculateArea(int x); 
//	int calculatePerimeter(int x);
}
