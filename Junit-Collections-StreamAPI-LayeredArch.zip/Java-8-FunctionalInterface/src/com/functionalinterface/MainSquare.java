package com.functionalinterface;

public class MainSquare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Square square = (int side)->( side * side); // implementation of function
		
		int area = square.calculateArea(6);
		
		System.out.println("Area of square : " + area);

	}

}
