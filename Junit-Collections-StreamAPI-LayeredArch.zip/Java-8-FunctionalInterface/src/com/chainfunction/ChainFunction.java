package com.chainfunction;

import java.util.function.Function;

public class ChainFunction {
	public static void main(String[] args) {
		
		Function<Integer, Integer> times2 = num -> num * 2;
		
		Function<Integer, Integer> squared = num -> num * num;  
		
		// calculate square and multiplies it with 2 - returns 32	
		System.out.println( times2.compose(squared).apply(2) ); // evaluates from apply to compose  
		// Returns 32
		// calculate square and multiplies it with 2 - returns 64
		System.out.println(times2.andThen(squared).apply(5)); // evaluates from times2 and squares
		
		
		// string and integer args
		
		
		
        Function<String, Integer> func = str -> str.length();

        Function<Integer, Integer> func2 = num -> num * 3;

        Integer result = func.andThen(func2).apply("Sagar");   // Returns 5

        System.out.println("No of characters " + result);

    }
}
