
public class Sample {

	public static void main(String[] args) {
		String threadName = Thread.currentThread().getName();
		System.out.println("Hello " + threadName);

	}

}
