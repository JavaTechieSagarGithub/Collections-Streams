package com.mycompany.library.dao;

// persistence layer

import java.util.ArrayList;

import com.mycompany.library.entity.Book;

public class BookDAO {
	ArrayList<Book> bookList = new ArrayList<Book>();
	/**************** Inserting book Details *********************************/
	public ArrayList<Book> getBooks() {
		return bookList;
	}
	public void insertBookDetails(Book book)  {
		bookList.add(book);
	}
	/******************** Show list of books ********************************/
	public void showBookList(ArrayList<Book> bookList) {
		System.out.println("In showBookList method  " + bookList.size());
		for (Book book : bookList) {
			System.out.println(book.getBookId());
			System.out.println(book.getBname());
			System.out.println(book.getAuthor());
			System.out.println(book.getPrice());
		}
	}
	/**************** Updating book Details *********************************/
	public void updateBook(int id)  {
		for (Book book : bookList) {
			if(book.getBookId() == id) {
				book.setPrice((book.getPrice() + book.getPrice() *0.10f)) ;
			}
		}
	}
	
	/**************** Deleting book Details *********************************/
	public void deleteBook(int id) {
		for (Book book : bookList) {
			if(book.getBookId() == id) {
				bookList.remove(book);
			}
		}

	}
	

}// end of dao class