package com.mycompany.library.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.mycompany.library.dao.BookDAO;
import com.mycompany.library.entity.Book;

public class BookServiceProvider {
	
	//ArrayList<Book>  bookList = new ArrayList<Book>(); 
	BookDAO bookDAO = new BookDAO();
	
	
	// Showing book data service
	public void showBooksService(ArrayList<Book> bookList) {
		bookList = bookDAO.getBooks();
		bookDAO.showBookList(bookList);
//		System.out.println( "In service layer " + bookList.size() );
	}
	
	//Inserting book data service
	public void insertBookService(Book book)  {
		bookDAO.insertBookDetails(book);
	}
	
	// deleting book data service
	public void deleteBookService(int id)  {
		bookDAO.deleteBook(id);
	}
	public void updateBookService(int id)   {
		bookDAO.updateBook(id);
	}
	
}
